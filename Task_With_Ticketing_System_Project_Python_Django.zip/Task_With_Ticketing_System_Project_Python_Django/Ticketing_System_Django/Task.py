#  For a input of two strings X and Y, find the minimum number of steps required to convert X to Y. (each operation is counted as 1 step.)
#
# You have the following 3 operations permitted on a word:
#
# Insert a character
# Delete a character
# Replace a character
#
#
# Example:
#
# Input 1:
# X = "abad"
# Y = "abac"
#
# Output 1:
# 1
#
# Explanation 1:
# Operation 1: Replace d with c.
#
# Input 2:
# X = "Insa"
# Y = "India"
#
# Output 2:
# 2
#
# Explanation 2:
# => Operation 1: Replace s with d.
# Operation 2: Insert i.

def minDistance(X, Y):
    m,n=len(X),len(Y)
    #Create a 2D table for dynamic programming
    dp=[[0]*(n+1) for p in range(m+n)]
    # # Initialize first row and column
    for i in range(m+1):
        dp[i][0]=i  # i deletion
    for j in range(n+1):
        dp[0][j]=j  #j insertion

    #Fill the table
    for i in range(1,m+1):
        for j in range(1,n+1):
            if X[i-1]==Y[j-1]:
                dp[i][j]=dp[i-1][j-1]## No change needed
            else:
                dp[i][j]=1+min(dp[i-1][j], ## Deletion
                               dp[i][j-1],  # Insertion
                               dp[i-1][j-1]) # Replacement
    return dp[m][n]
print(minDistance("abad","abac"))
print(minDistance("Insa","India"))


# 2) Write a program that accepts a sequence of whitespace separated words as input and prints
# the words after removing all duplicate words and sorting them alphanumerically. (Don't use sort function or any other inbuilt function)
#
# Input: hello world and practice makes perfect and hello world again
# Output: again and hello makes perfect practice world

s="hello world and practice makes perfect and hello world again"
res=[]
s1=s.split()
for word in s1:
    if word not in res:
        res.append(word)
for i in range(len(res)):
    for j in range(i+1,len(res)):
        if res[i]>res[j]:
            res[i],res[j]=res[j],res[i]
print(" ".join(res))




