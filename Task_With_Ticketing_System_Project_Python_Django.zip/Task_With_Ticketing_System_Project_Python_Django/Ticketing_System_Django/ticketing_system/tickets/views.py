from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from .models import Ticket,User,TicketAttachment
from django.contrib.auth.decorators import login_required
from django.contrib.auth import  login, logout
from django.contrib.auth.forms import  AuthenticationForm

@login_required
def staff_dashboard(request):
    user=request.user
    if not user.is_staff_user:
        return redirect('admin:index')
    tickets=Ticket.objects.filter(assigned_to=user)
    return render(request, 'staff/dashboard.html', {
        'draft': tickets.filter(status='draft').count(),
        'ongoing': tickets.filter(status='ongoing').count(),
        'completed': tickets.filter(status='completed').count(),
    })


def auth_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            # Check if staff user
            if user.is_staff_user:
                return redirect('staff_dashboard')  # URL name defined in urls.py
            else:
                return redirect('admin:index')  # Or any other route for non-staff users
    else:
        form = AuthenticationForm()
    return render(request, 'auth/login.html', {'form': form})
@login_required
def staff_tickets(request):
    user = request.user  # logged-in user
    # Only show tickets assigned to this user (and not archived)
    tickets = Ticket.objects.filter(assigned_to=user).exclude(status='archived')

    # Optional: Filtering by status using query parameter (like ?status=ongoing)
    status = request.GET.get('status')
    if status in ['draft', 'ongoing', 'completed']:
        tickets = tickets.filter(status=status)
    
    search = request.GET.get('search')
    if search:
        tickets = tickets.filter(name__icontains=search)

    return render(request, 'staff/tickets.html', {'tickets': tickets})

@login_required
def update_ticket_by_name(request, ticket_name):
    ticket = get_object_or_404(Ticket, name=ticket_name, assigned_to=request.user)

    if request.method == 'POST':
        status = request.POST.get('status')
        if status in ['ongoing', 'completed']:
            ticket.status = status
            ticket.save()
            # handle attachments if needed
            for f in request.FILES.getlist('attachments'):
                TicketAttachment.objects.create(ticket=ticket, file=f)
        return redirect('ticket_detail',name=ticket.name)

    return render(request, 'staff/update_status.html', {'ticket': ticket})

@login_required
def ticket_detail(request, name):
    ticket = get_object_or_404(Ticket, name=name, assigned_to=request.user)
    return render(request, 'staff/ticket_detail.html', {'ticket': ticket})

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')