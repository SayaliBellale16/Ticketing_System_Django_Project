from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import AbstractUser


class Project(models.Model):
    name=models.CharField(max_length=100)

    def __str__(self):
        return self.name
class User(AbstractUser):
    is_staff_user=models.BooleanField(default=False)
    projects=models.ManyToManyField(Project,blank=True)

class Ticket(models.Model):
    STATUS_CHOICES=[('draft','Draft'),
                    ('ongoing','Ongoing'),
                    ('completed','Completed'),
                    ('archived','Archived')]
    name=models.CharField(max_length=100,unique=True)
    description=models.TextField()
    assigned_to=models.ForeignKey(User,on_delete=models.SET_NULL,null=True,blank=True)
    project=models.ForeignKey(Project,on_delete=models.SET_NULL,null=True,blank=True)
    status=models.CharField(max_length=20,choices=STATUS_CHOICES,default='draft')
    created_at=models.DateTimeField(auto_now=True)
    updated_at=models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
    
class TicketAttachment(models.Model):
    ticket=models.ForeignKey(Ticket,on_delete=models.CASCADE,related_name='attachments')
    file=models.FileField(upload_to='attachments/')
    uploaded_at=models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Attachment for {self.ticket.name}"
