from django.urls import path
from . import views

urlpatterns=[
    path('dashboard/', views.staff_dashboard, name='staff_dashboard'),
    path('login/', views.auth_login, name='login'),
    path('tickets/', views.staff_tickets, name='staff_tickets'),
    path('tickets/<str:name>/', views.ticket_detail, name='ticket_detail'),
    path('tickets/update_by_name/<str:ticket_name>/', views.update_ticket_by_name, name='update_ticket_by_name'),
    path('logout/', views.logout_view, name='logout'),

]